import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { take, map } from 'rxjs/operators';
import { TransitionService } from 'src/app/core/services/transition.service';

@Injectable({
  providedIn: 'root'
})
export class ShutterGuard implements CanActivate {

  constructor(private router: Router, private transitionService: TransitionService) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> {

    console.log(performance.now(), 'ShutterGuard: Navigation started to', next.url);

    console.log(performance.now(), 'ShutterGuard: TEMPORARY - Allowing navigation immediately.');
    return of(true);
  }
}

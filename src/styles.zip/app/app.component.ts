import { Component, OnInit, OnDestroy } from '@angular/core';
import { trigger, transition, style, animate, query, group } from '@angular/animations';
import { RouterOutlet, Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { TransitionService } from './core/services/transition.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('routeAnimations', [
      transition('* <=> *', [
        style({ position: 'relative' }),
        query(':enter, :leave', [
          style({
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%'
          })
        ], { optional: true }),
        query(':enter', [
          style({ opacity: 0, transform: 'scale(0.95)' }) // Initial state for new page: slightly scaled down and invisible
        ], { optional: true }),
        group([
          query(':leave', [
            animate('0.3s ease-out', style({ opacity: 0, transform: 'scale(1.05)' })) // Animate old page out: fade and slightly scale up
          ], { optional: true }),
          query(':enter', [
            animate('0.5s ease-in-out', style({ opacity: 1, transform: 'scale(1)' })) // Animate new page in: fade and scale to normal
          ], { optional: true })
        ])
      ])
    ])
  ]
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'photographer-portfolio';
  private routerEventsSubscription!: Subscription;

  constructor(private router: Router, private transitionService: TransitionService) { }

  ngOnInit(): void {
    this.routerEventsSubscription = this.router.events.subscribe(event => {
      console.log(performance.now(), 'Router Event:', event.constructor.name);

      if (event instanceof NavigationStart) {
        // When navigation starts, show the shutter
        console.log(performance.now(), 'NavigationStart: Calling showShutter()');
        this.transitionService.showShutter();
      } else if (event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError) {
        // When navigation ends (successfully, cancelled, or errored), hide the shutter
        console.log(performance.now(), 'NavigationEnd/Cancel/Error: Calling hideShutter()');
        this.transitionService.hideShutter();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.routerEventsSubscription) {
      this.routerEventsSubscription.unsubscribe();
    }
  }

  // Helper function to get the state for the router outlet animation
  getRouteAnimationState(outlet: RouterOutlet) {
    return outlet.activatedRouteData['animation'] || 'default';
  }
}
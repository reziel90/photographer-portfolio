import { Component, OnInit, OnDestroy, ViewChildren, ElementRef, QueryList, AfterViewInit, ViewChild } from '@angular/core';
import { TransitionService } from 'src/app/core/services/transition.service';
import { Subscription, Observable, take } from 'rxjs';

@Component({
  selector: 'app-shutter-transition',
  templateUrl: './shutter-transition.component.html',
  styleUrls: ['./shutter-transition.component.css']
})
export class ShutterTransitionComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChildren('blade') blades!: QueryList<ElementRef>;
  @ViewChild('shutterOverlay') shutterOverlay!: ElementRef;

  private transitionSubscription!: Subscription;
  private bladesChangesSubscription!: Subscription;
  public showShutter$: Observable<boolean>;
  private bladesInitialized: boolean = false;

  constructor(private transitionService: TransitionService) {
    this.showShutter$ = this.transitionService.shutterState$;
  }

  ngOnInit(): void {
    // Subscription moved to ngAfterViewInit to ensure blades are initialized
  }

  ngAfterViewInit(): void {
    console.log(performance.now(), 'ShutterTransitionComponent: ngAfterViewInit called.');
    console.log(performance.now(), 'ShutterTransitionComponent: Initial blades length:', this.blades ? this.blades.length : 'undefined');

    // Initial check if blades are already available (e.g., if showShutter$ was true from start)
    if (this.blades && this.blades.length > 0) {
      this.initializeBlades();
    } else {
      console.warn(performance.now(), 'ShutterTransitionComponent: Blades not available in initial ngAfterViewInit.');
    }

    // Subscribe to changes in the QueryList for when *ngIf renders the blades
    this.bladesChangesSubscription = this.blades.changes.subscribe((queryList: QueryList<ElementRef>) => {
      console.log(performance.now(), 'ShutterTransitionComponent: blades.changes subscription fired. QueryList length:', queryList.length);
      if (queryList.length > 0 && !this.bladesInitialized) {
        this.initializeBlades();
      }
    });
  }

  private initializeBlades(): void {
    this.bladesInitialized = true;
    console.log(performance.now(), 'ShutterTransitionComponent: Blades initialized via initializeBlades().');

    // Subscribe to shutterState$ here, after blades are initialized
    this.transitionSubscription = this.transitionService.shutterState$.subscribe(state => {
      console.log(performance.now(), 'ShutterTransitionComponent: shutterState$ changed to', state);
      if (state) {
        // Shutter is becoming visible (closing animation)
        console.log(performance.now(), 'ShutterTransitionComponent: Playing close animation');
        if (this.shutterOverlay) {
          this.shutterOverlay.nativeElement.classList.remove('shutter-closed');
        }
        this.playCloseAnimation(() => {
          if (this.shutterOverlay) {
            this.shutterOverlay.nativeElement.classList.add('shutter-closed');
          }
          console.log(performance.now(), 'ShutterTransitionComponent: Close animation callback executed');
        });
      } else {
        // Shutter is becoming invisible (opening animation)
        console.log(performance.now(), 'ShutterTransitionComponent: Playing open animation');
        if (this.shutterOverlay) {
          this.shutterOverlay.nativeElement.classList.add('shutter-closed');
        }
        this.playOpenAnimation(() => {
          if (this.shutterOverlay) {
            this.shutterOverlay.nativeElement.classList.remove('shutter-closed');
          }
          console.log(performance.now(), 'ShutterTransitionComponent: Open animation callback executed');
        });
      }
    });

    // Initial state: ensure shutter is open (hidden) when component is first rendered
    // This handles cases where the component is rendered and immediately needs to be open
    this.showShutter$.pipe(take(1)).subscribe(isShutterClosed => {
      if (!isShutterClosed) { // If the initial state is 'open'
        console.log(performance.now(), 'ShutterTransitionComponent: Initial open animation triggered from initializeBlades().');
        this.playOpenAnimation();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.transitionSubscription) {
      this.transitionSubscription.unsubscribe();
    }
    if (this.bladesChangesSubscription) { // Unsubscribe from new subscription
      this.bladesChangesSubscription.unsubscribe();
    }
  }

  private playCloseAnimation(callback?: () => void): void {
    console.log(performance.now(), 'playCloseAnimation called. Current blades length:', this.blades ? this.blades.length : 'undefined');
    if (!this.bladesInitialized) {
      console.warn(performance.now(), 'Blades not initialized yet, skipping close animation.');
      if (callback) callback();
      this.transitionService.signalShutterClosed();
      return;
    }
    const duration = 1000; // ms
    let animationsCompleted = 0;
    const totalBlades = this.blades.length;

    this.blades.forEach((blade, index) => {
      const bladeEl = blade.nativeElement;
      const initialRotation = index * 60;
      let finalRotation: number;
      if (index < 3) {
        finalRotation = initialRotation + 60;
      } else {
        finalRotation = initialRotation - 60;
      }
      console.log(performance.now(), `Blade ${index}: initialRotation=${initialRotation}, finalRotation=${finalRotation}`);
      bladeEl.style.setProperty('--initial-rotation', `${initialRotation}deg`);
      bladeEl.style.setProperty('--final-rotation', `${finalRotation}deg`);
      bladeEl.style.animation = `shutter-close ${duration / 1000}s linear forwards`;

      let animationEnded = false;
      const onAnimationEnd = () => {
        if (!animationEnded) {
          animationsCompleted++;
          if (animationsCompleted === totalBlades) {
            console.log(performance.now(), 'Blades Close Animation Completed');
            setTimeout(() => {
              console.log(performance.now(), 'Flash timeout triggered');
              const flashEl = document.querySelector('.shutter-flash') as HTMLElement;
              if (flashEl) {
                console.log(performance.now(), 'Flash element found, playing animation');
                flashEl.style.animation = `flash-animation 0.2s linear forwards`;
                flashEl.onanimationend = () => {
                  console.log(performance.now(), 'Flash animation ended');
                  flashEl.style.animation = '';
                  if (callback) callback();
                  this.transitionService.signalShutterClosed();
                };
              } else {
                console.log(performance.now(), 'Flash element not found');
                if (callback) callback();
                this.transitionService.signalShutterClosed();
              }
            }, 0);
          }
          animationEnded = true;
        }
        bladeEl.removeEventListener('animationend', onAnimationEnd);
      };

      bladeEl.addEventListener('animationend', onAnimationEnd);

      setTimeout(() => {
        onAnimationEnd();
      }, duration + 50);
    });
  }

  private playOpenAnimation(callback?: () => void): void {
    console.log(performance.now(), 'playOpenAnimation called. Current blades length:', this.blades ? this.blades.length : 'undefined');
    if (!this.bladesInitialized) {
      console.warn(performance.now(), 'Blades not initialized yet, skipping open animation.');
      if (callback) callback();
      return;
    }
    const duration = 1000; // ms
    let animationsCompleted = 0;
    const totalBlades = this.blades.length;

    this.blades.forEach((blade, index) => {
      const bladeEl = blade.nativeElement;
      const initialRotation = index * 60;
      let finalRotation: number;
      if (index < 3) {
        finalRotation = initialRotation + 60;
      } else {
        finalRotation = initialRotation - 60;
      }
      console.log(performance.now(), `Blade ${index}: initialRotation=${initialRotation}, finalRotation=${finalRotation}`);
      bladeEl.style.setProperty('--initial-rotation', `${initialRotation}deg`);
      bladeEl.style.setProperty('--final-rotation', `${finalRotation}deg`);
      blade.nativeElement.style.animation = `shutter-open ${duration / 1000}s linear forwards`;

      let animationEnded = false;
      const onAnimationEnd = () => {
        if (!animationEnded) {
          animationsCompleted++;
          if (animationsCompleted === totalBlades) {
            console.log(performance.now(), 'Blades Open Animation Completed');
            if (callback) callback();
          }
          animationEnded = true;
        }
        bladeEl.removeEventListener('animationend', onAnimationEnd);
      };

      bladeEl.addEventListener('animationend', onAnimationEnd);

      setTimeout(() => {
        onAnimationEnd();
      }, duration + 50);
    });
  }
}